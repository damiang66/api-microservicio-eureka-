package com.damian.comun.msvcusuarioscomun;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MsvcUsuariosComunApplicationTests {

	@Test
	void contextLoads() {
	}

}
