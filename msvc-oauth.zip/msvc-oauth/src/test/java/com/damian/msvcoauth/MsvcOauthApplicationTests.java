package com.damian.msvcoauth;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MsvcOauthApplicationTests {

	@Test
	void contextLoads() {
	}

}
